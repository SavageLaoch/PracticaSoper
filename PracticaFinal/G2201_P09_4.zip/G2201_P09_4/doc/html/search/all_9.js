var searchData=
[
  ['retorno',['retorno',['../utils_8c.html#a5ac218d80df148510254fb10e6cde3b2',1,'utils.c']]]
];
