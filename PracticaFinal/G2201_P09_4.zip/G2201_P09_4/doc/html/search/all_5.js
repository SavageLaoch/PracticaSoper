var searchData=
[
  ['gestor_5fapuestas',['gestor_apuestas',['../gestor__apuestas_8c.html#a6a9b55a423bec0b3b99bbcbc76077a14',1,'gestor_apuestas.c']]],
  ['gestor_5fapuestas_2ec',['gestor_apuestas.c',['../gestor__apuestas_8c.html',1,'']]]
];
