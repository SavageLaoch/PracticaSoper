var searchData=
[
  ['aleat_5fnum',['aleat_num',['../utils_8c.html#a423be02d237888f767b6d107096c10f4',1,'utils.c']]],
  ['apostador',['apostador',['../apostador_8c.html#a7f59443269aa1df122364df788a67dfe',1,'apostador.c']]],
  ['avanzar_5fcaballo',['avanzar_caballo',['../caballos_8c.html#ae08aca4dce76d2968072ac8845c8a54d',1,'caballos.c']]]
];
