var searchData=
[
  ['_5festructura',['_Estructura',['../struct__Estructura.html',1,'']]],
  ['_5fmemcomp',['_MemComp',['../struct__MemComp.html',1,'']]],
  ['_5fmensaje',['_Mensaje',['../struct__Mensaje.html',1,'']]]
];
