var searchData=
[
  ['main',['main',['../principal_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'principal.c']]],
  ['monitor',['monitor',['../monitor_8c.html#ac33ad7cfdcd6b75d1f881bf84b508b38',1,'monitor.c']]],
  ['monitor_2ec',['monitor.c',['../monitor_8c.html',1,'']]],
  ['monitor_5fantes',['monitor_antes',['../monitor_8c.html#aa37d1db7160f06eb443ee4e108cc2d8b',1,'monitor.c']]],
  ['monitor_5fdespues',['monitor_despues',['../monitor_8c.html#a6a1066145b6564de24f12f499c747b36',1,'monitor.c']]],
  ['monitor_5fdurante',['monitor_durante',['../monitor_8c.html#ae2c7c9dbd5ea9a629fd0174a39ace169',1,'monitor.c']]]
];
