var searchData=
[
  ['gestor_5fapuestas_2ec',['gestor_apuestas.c',['../gestor__apuestas_8c.html',1,'']]]
];
