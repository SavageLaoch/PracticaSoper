var searchData=
[
  ['apostador_2ec',['apostador.c',['../apostador_8c.html',1,'']]]
];
