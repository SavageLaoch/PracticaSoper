var searchData=
[
  ['ventanilla',['ventanilla',['../gestor__apuestas_8c.html#a619cd77af45176fcd6d079acac529dfb',1,'gestor_apuestas.c']]]
];
