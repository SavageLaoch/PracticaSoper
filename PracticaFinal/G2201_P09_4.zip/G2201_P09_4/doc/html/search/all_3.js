var searchData=
[
  ['caballo',['caballo',['../caballos_8c.html#aee3c421c21c50ae6923c56d630103bd2',1,'caballos.c']]],
  ['caballos_2ec',['caballos.c',['../caballos_8c.html',1,'']]],
  ['carrera',['carrera',['../carrera_8c.html#a98cc354452ede1059c5980ca16b800e9',1,'carrera.c']]],
  ['carrera_2ec',['carrera.c',['../carrera_8c.html',1,'']]],
  ['crear_5fsemaforo',['Crear_Semaforo',['../semaforos_8c.html#a16b16dd895b5f4cbe48f1ac8977e8b35',1,'Crear_Semaforo(key_t key, int size, int *semid):&#160;semaforos.c'],['../semaforos_8h.html#a16b16dd895b5f4cbe48f1ac8977e8b35',1,'Crear_Semaforo(key_t key, int size, int *semid):&#160;semaforos.c']]]
];
