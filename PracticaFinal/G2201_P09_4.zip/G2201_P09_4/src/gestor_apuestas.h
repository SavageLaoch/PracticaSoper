#ifndef GESTOR_APUESTAS_H
#define GESTOR_APUESTAS_H

void gestor_apuestas(int num_ventanillas,int num_caballos,int num_apostadores,int msqid,int id_zone,int sem_id);

#endif
