#ifndef CARRERA_H
#define CARRERA_H

void carrera(int num_caballos,int max_distancia,int num_apostadores,int num_ventanillas,int max_dinero,int **pipes,int msqid, int sem_id, int id_zone);

#endif
