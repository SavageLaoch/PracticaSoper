#ifndef APOSTADOR_H
#define APOSTADOR_H

void apostador(int num_apostadores,int num_caballos,int max_dinero,int msqid);

#endif
