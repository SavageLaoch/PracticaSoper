#ifndef CABALLOS_H
#define CABALLOS_H

int dado(int modo);

int avanzar_caballo(int posicion);

void caballo(int pipe[2],int msqid);

#endif
