var searchData=
[
  ['_5fmensaje',['_Mensaje',['../struct__Mensaje.html',1,'']]]
];
