var searchData=
[
  ['up_5fsemaforo',['Up_Semaforo',['../semaforos_8c.html#a2d5e735aecee4f493898b3d4ebab1a10',1,'Up_Semaforo(int id, int num_sem, int undo):&#160;semaforos.c'],['../semaforos_8h.html#a2d5e735aecee4f493898b3d4ebab1a10',1,'Up_Semaforo(int id, int num_sem, int undo):&#160;semaforos.c']]],
  ['upmultiple_5fsemaforo',['UpMultiple_Semaforo',['../semaforos_8c.html#a943759695f018d64a94b8a2c49308092',1,'UpMultiple_Semaforo(int id, int size, int undo, int *active):&#160;semaforos.c'],['../semaforos_8h.html#a943759695f018d64a94b8a2c49308092',1,'UpMultiple_Semaforo(int id, int size, int undo, int *active):&#160;semaforos.c']]]
];
