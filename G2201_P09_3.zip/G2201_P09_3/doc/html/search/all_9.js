var searchData=
[
  ['producir_5fitem',['producir_item',['../ejercicio3_8c.html#afeaf06b1b0bec188bc6e29a09662b85b',1,'ejercicio3.c']]]
];
