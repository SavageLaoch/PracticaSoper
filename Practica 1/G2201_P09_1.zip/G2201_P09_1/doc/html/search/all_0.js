var searchData=
[
  ['_5festructura',['_Estructura',['../struct__Estructura.html',1,'']]],
  ['_5fmatriz',['_Matriz',['../struct__Matriz.html',1,'']]]
];
