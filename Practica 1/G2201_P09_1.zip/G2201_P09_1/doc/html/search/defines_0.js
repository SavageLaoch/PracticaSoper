var searchData=
[
  ['num_5fproc',['NUM_PROC',['../Ejercicio4a_8c.html#acee2369f62e4a096d243dec3cd7d0b00',1,'NUM_PROC():&#160;Ejercicio4a.c'],['../Ejercicio4b_8c.html#acee2369f62e4a096d243dec3cd7d0b00',1,'NUM_PROC():&#160;Ejercicio4b.c'],['../Ejercicio4moda_8c.html#acee2369f62e4a096d243dec3cd7d0b00',1,'NUM_PROC():&#160;Ejercicio4moda.c'],['../Ejercicio4modb_8c.html#acee2369f62e4a096d243dec3cd7d0b00',1,'NUM_PROC():&#160;Ejercicio4modb.c'],['../Ejercicio9_8c.html#acee2369f62e4a096d243dec3cd7d0b00',1,'NUM_PROC():&#160;Ejercicio9.c']]]
];
