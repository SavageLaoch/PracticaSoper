var searchData=
[
  ['tam',['tam',['../Ejercicio13_8c.html#a76145a5161e42fad3d104769414503c6',1,'tam():&#160;Ejercicio13.c'],['../Ejercicio13mod_8c.html#a76145a5161e42fad3d104769414503c6',1,'tam():&#160;Ejercicio13mod.c']]]
];
