var searchData=
[
  ['comprueba_5fprimos',['comprueba_primos',['../Ejercicio12a_8c.html#af611ad3eeca03b941c75b93cc43fb762',1,'comprueba_primos(void *estructura):&#160;Ejercicio12a.c'],['../Ejercicio12b_8c.html#a9310c3d3e45ca12629b8d5bb2944f4d9',1,'comprueba_primos(void *estructura):&#160;Ejercicio12b.c']]]
];
