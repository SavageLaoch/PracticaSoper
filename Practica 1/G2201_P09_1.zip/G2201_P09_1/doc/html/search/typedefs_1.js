var searchData=
[
  ['matriz',['Matriz',['../Ejercicio13_8c.html#a7109e4e5f39431dfb63fa24382c03b8f',1,'Matriz():&#160;Ejercicio13.c'],['../Ejercicio13mod_8c.html#a7109e4e5f39431dfb63fa24382c03b8f',1,'Matriz():&#160;Ejercicio13mod.c']]]
];
