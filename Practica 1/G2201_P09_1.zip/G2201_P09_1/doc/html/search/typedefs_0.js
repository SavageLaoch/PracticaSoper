var searchData=
[
  ['estructura',['Estructura',['../Ejercicio12a_8c.html#a1784ecaa6952782e8d25940829f26f2a',1,'Estructura():&#160;Ejercicio12a.c'],['../Ejercicio12b_8c.html#a1784ecaa6952782e8d25940829f26f2a',1,'Estructura():&#160;Ejercicio12b.c'],['../Ejercicio6_8c.html#a1784ecaa6952782e8d25940829f26f2a',1,'Estructura():&#160;Ejercicio6.c']]]
];
