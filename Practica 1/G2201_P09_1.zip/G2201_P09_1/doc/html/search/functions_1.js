var searchData=
[
  ['ejecutar',['ejecutar',['../Ejercicio8_8c.html#a4b9ba84710846fee07889b2bb7c22202',1,'Ejercicio8.c']]],
  ['es_5fprimo',['es_primo',['../Ejercicio12a_8c.html#ac02bef7a39b0ee8465f8661d9438e1dd',1,'es_primo(int num):&#160;Ejercicio12a.c'],['../Ejercicio12b_8c.html#ac02bef7a39b0ee8465f8661d9438e1dd',1,'es_primo(int num):&#160;Ejercicio12b.c']]]
];
