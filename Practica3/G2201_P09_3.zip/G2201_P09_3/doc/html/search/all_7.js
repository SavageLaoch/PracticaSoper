var searchData=
[
  ['leer_5ffichero',['leer_fichero',['../ejercicio4_8c.html#a77dea457a35331c16034e30ae8773487',1,'ejercicio4.c']]]
];
