var searchData=
[
  ['consumir_5fitem',['consumir_item',['../ejercicio3_8c.html#a9072448f8691277551026658b1eecd14',1,'ejercicio3.c']]],
  ['crear_5ffichero',['crear_fichero',['../ejercicio4_8c.html#ac715c03938b31f96f34f672c496a473d',1,'ejercicio4.c']]],
  ['crear_5fsemaforo',['Crear_Semaforo',['../semaforos_8c.html#a16b16dd895b5f4cbe48f1ac8977e8b35',1,'Crear_Semaforo(key_t key, int size, int *semid):&#160;semaforos.c'],['../semaforos_8h.html#a16b16dd895b5f4cbe48f1ac8977e8b35',1,'Crear_Semaforo(key_t key, int size, int *semid):&#160;semaforos.c']]]
];
