var searchData=
[
  ['main',['main',['../ejercicio2_8c.html#abf9e6b7e6f15df4b525a2e7705ba3089',1,'main(int argc, char const *argv[]):&#160;ejercicio2.c'],['../ejercicio2__solved_8c.html#abf9e6b7e6f15df4b525a2e7705ba3089',1,'main(int argc, char const *argv[]):&#160;ejercicio2_solved.c'],['../ejercicio3_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;ejercicio3.c'],['../ejercicio4_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;ejercicio4.c'],['../ejercicio5_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;ejercicio5.c']]],
  ['manejador',['manejador',['../ejercicio2_8c.html#a41f66b426edc83163dca59e49431a9d3',1,'manejador(int sig):&#160;ejercicio2.c'],['../ejercicio2__solved_8c.html#a41f66b426edc83163dca59e49431a9d3',1,'manejador(int sig):&#160;ejercicio2_solved.c']]]
];
