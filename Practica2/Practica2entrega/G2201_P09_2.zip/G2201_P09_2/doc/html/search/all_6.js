var searchData=
[
  ['leerturno',['LeerTurno',['../Ejercicio9_8c.html#a42f959d3fed290177039527b23acdd1a',1,'Ejercicio9.c']]]
];
